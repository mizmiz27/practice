export const formOption = () => {
  // emailで入力した項目の即時反映
  var input = document.querySelector('.formParts__email');
  var p = document.querySelector('.formParts__emailConfirmText');

  input.addEventListener('input', function() {
    var email = input.value;
    p.textContent = email;
    p.scrollLeft = p.scrollWidth - p.clientWidth;
  });


  var form = document.querySelector('#formBlock');
  const error_email = document.querySelector('.error_email');
  const error_selectDay = document.querySelector('.error_selectDay');
  const error_name = document.querySelector('.error_name');
  const error_kana = document.querySelector('.error_kana');
  const error_gender = document.querySelector('.error_gender');
  const error_address = document.querySelector('.error_address');
  const error_zipCode = document.querySelector('.error_zipCode');
  const error_telSelf = document.querySelector('.error_telSelf');
  const error_telHome = document.querySelector('.error_telHome');
  const error_commuting = document.querySelector('.error_commuting');
  const error_gakusei = document.querySelector('.error_gakusei');
  const error_nyugaku = document.querySelector('.error_nyugaku');
  const error_selectFaculty = document.querySelector('.error_selectFaculty');
  const error_selectEntrance = document.querySelector('.error_selectEntrance');
  const submitBtn = document.getElementById('submitBtn');

  form.addEventListener('submit', function(event) {
  event.preventDefault();

  var inputs = form.querySelectorAll('.required__email, .required__selectDay, .required__selectFaculty, .required__selectEntrance, .required__name, .required__kana, .required__gender, .required__address, .required__zipCode, .required__telSelf, .required__telHome, .required__commuting, .required__gakusei, .required__nyugaku');
  var isValid = true;

  function isChecked(input) {
    var radioGroup = form.querySelector('input[name="' + input.name + '"]:checked');
    return radioGroup !== null;
  }

  for (var i = 0; i < inputs.length; i++) {
    var input = inputs[i];
    // var errorMessage = errorMessages[i];

    var value = input.value.trim();

    if (input.classList.contains('required__email') && value === '') {
      input.classList.add('u-error');
      error_email.textContent = 'メールアドレスは必須です';
      error_email.style.display = 'inline-block';
      isValid = false;
    } else if (input.classList.contains('required__selectDay') && value === 'default') {
      input.classList.add('u-error');
      error_selectDay.textContent = '生年月日は必須です';
      error_selectDay.style.display = 'inline-block';
      isValid = false;
    } else if (input.classList.contains('required__name') && value === '') {
      input.classList.add('u-error');
      error_name.textContent = '氏名は必須です';
      error_name.style.display = 'inline-block';
      isValid = false;
    } else if (input.classList.contains('required__kana') && value === '') {
      input.classList.add('u-error');
      error_kana.textContent = 'フリガナは必須です';
      error_kana.style.display = 'inline-block';
      isValid = false;
    } else if (input.classList.contains('required__gender') && !isChecked(input)) {
      input.nextElementSibling.classList.add('u-error');
      error_gender.textContent = '性別は必須です';
      error_gender.style.display = 'inline-block';
      isValid = false;
    } else if (input.classList.contains('required__address') && !isChecked(input)) {
      input.nextElementSibling.classList.add('u-error');
      error_address.textContent = 'いずれかを選択してください';
      error_address.style.display = 'inline-block';
      isValid = false;
    } else if (input.classList.contains('required__zipCode') && value === '') {
      input.classList.add('u-error');
      error_zipCode.textContent = '住所は必須です';
      error_zipCode.style.display = 'inline-block';
      isValid = false;
    } else if (input.classList.contains('required__telSelf') && value === '') {
      input.classList.add('u-error');
      error_telSelf.textContent = '携帯電話番号は必須です';
      error_telSelf.style.display = 'inline-block';
      isValid = false;
    } else if (input.classList.contains('required__telHome') && value === '') {
      input.classList.add('u-error');
      error_telHome.textContent = '自宅電話番号は必須です';
      error_telHome.style.display = 'inline-block';
      isValid = false;
    } else if (input.classList.contains('required__commuting') && !isChecked(input)) {
      input.nextElementSibling.classList.add('u-error');
      error_commuting.textContent = '通学種別は必須です';
      error_commuting.style.display = 'inline-block';
      isValid = false;
    } else if (input.classList.contains('required__gakusei') && !isChecked(input)) {
      input.nextElementSibling.classList.add('u-error');
      error_gakusei.textContent = '学生区分は必須です';
      error_gakusei.style.display = 'inline-block';
      isValid = false;
    } else if (input.classList.contains('required__nyugaku') && !isChecked(input)) {
      input.nextElementSibling.classList.add('u-error');
      error_nyugaku.textContent = '入学区分は必須です';
      error_nyugaku.style.display = 'inline-block';
      isValid = false;
    } else if (input.classList.contains('required__selectFaculty') && value === 'default') {
      input.classList.add('u-error');
      error_selectFaculty.textContent = '所属学部・学科は必須です';
      error_selectFaculty.style.display = 'inline-block';
      isValid = false;
    } else if (input.classList.contains('required__selectEntrance') && value === 'default') {
      input.classList.add('u-error');
      error_selectEntrance.textContent = '入学年月は必須です';
      error_selectEntrance.style.display = 'inline-block';
      isValid = false;
    } else {
    }

    // $(inputs).on('change', function () {
    //   console.log('ok');
    //   if (isValid = true) {
    //     submitBtn.removeAttribute('disabled');
    //   }
    // });
  }

  if (isValid) {
    form.submit();
  }
  });
  const inputTelSelf = document.getElementById('telSelf');
  const inputTelHome = document.getElementById('telHome');
  if (!inputTelSelf){ return false;}
  inputTelSelf.addEventListener('blur', () => {
    let validateTelNeo = function (value) {
      return /^[0０]/.test(value) && libphonenumber.isValidNumber(value, 'JP');
    }
    let formatTel = function (value) {
      return new libphonenumber.AsYouType('JP').input(value);
    }

    const postdata = inputTelSelf.value;
    if (!validateTelNeo(postdata)) {
      // console.log('ERROR')
      return
    }
    let formattedTel = formatTel(postdata);
    // console.log(formattedTel);
    inputTelSelf.value = formattedTel;
  });
  if (!inputTelHome){ return false;}
  inputTelHome.addEventListener('blur', () => {
    let validateTelNeo = function (value) {
      return /^[0０]/.test(value) && libphonenumber.isValidNumber(value, 'JP');
    }
    let formatTel = function (value) {
      return new libphonenumber.AsYouType('JP').input(value);
    }

    const postdata = inputTelHome.value;
    if (!validateTelNeo(postdata)) {
      // console.log('ERROR')
      return
    }
    let formattedTel = formatTel(postdata);
    // console.log(formattedTel);
    inputTelHome.value = formattedTel;
  });

//   $('#formBlock input, #formBlock select').on('change', function() {
//   var emailValue = $('.required__email').val();
//   var selectDayValue = $('.required__selectDay').val();
//   var nameValue = $('.required__name').val();
//   var kanaValue = $('.required__kana').val();
//   var genderChecked = $('input[name="gender"]:checked').length > 0;
//   var addressChecked = $('input[name="address"]:checked').length > 0;
//   var telSelfValue = $('.required__telSelf').val();
//   var telHomeValue = $('.required__telHome').val();
//   var commutingTypeChecked = $('input[name="commuting_type"]:checked').length > 0;
//   var selectFacultyValue = $('.required__selectFaculty').val();
//   var selectEntranceValue = $('.required__selectEntrance').val();
//   var gakuseiKubunChecked = $('input[name="gakusei_kubun"]:checked').length > 0;
//   var nyugakuKubunChecked = $('input[name="nyugaku_kubun"]:checked').length > 0;
//   var zipCodeValue = $('.required__zipCode').val();

//   var submitBtn = $('#submitBtn');

//   if (
//     emailValue !== "" &&
//     selectDayValue !== "default" &&
//     nameValue !== "" &&
//     kanaValue !== "" &&
//     genderChecked &&
//     addressChecked &&
//     telSelfValue !== "" &&
//     telHomeValue !== "" &&
//     commutingTypeChecked &&
//     selectFacultyValue !== "default" &&
//     selectEntranceValue &&
//     gakuseiKubunChecked &&
//     nyugakuKubunChecked &&
//     zipCodeValue !== ""
//   ) {
//     submitBtn.removeAttr('disabled');
//     submitBtn.removeClass('u-disabled');
//   } else {
//     submitBtn.attr('disabled', '');
//     submitBtn.addClass('u-disabled');
//   }
// });



}