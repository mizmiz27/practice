// プルダウンリスト　選択肢１つ目だけプレースホルダー風にする
export const selectHolder = () => {
  $('.formParts__select').on('change', function () {
    if ($(this).val() == "default") {
      $(this).css('color', '#A6A6A6');
      $(this).css('border', '1px solid #A6A6A6');
    } else {
      $(this).css('color', '#22201F', '');
      $(this).css('border', '1px solid #404040');
    }
  });
}